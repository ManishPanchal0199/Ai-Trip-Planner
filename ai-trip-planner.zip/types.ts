
export interface ItineraryDay {
  day: number;
  title: string;
  activities: string[];
  food_suggestions: string[];
}
