
import React, { useState, useCallback } from 'react';
import { ItineraryDay } from './types';
import { generateItinerary } from './services/geminiService';
import { Header } from './components/Header';
import { PlannerForm } from './components/PlannerForm';
import { ItineraryDisplay } from './components/ItineraryDisplay';
import { LoadingSpinner } from './components/LoadingSpinner';
import { ErrorMessage } from './components/ErrorMessage';
import { WelcomeMessage } from './components/WelcomeMessage';
import { Footer } from './components/Footer';

const App: React.FC = () => {
  const [itinerary, setItinerary] = useState<ItineraryDay[] | null>(null);
  const [isLoading, setIsLoading] = useState<boolean>(false);
  const [error, setError] = useState<string | null>(null);

  const handleGenerateItinerary = useCallback(async (destination: string, duration: number) => {
    setIsLoading(true);
    setError(null);
    setItinerary(null);
    try {
      const newItinerary = await generateItinerary(destination, duration);
      setItinerary(newItinerary);
    } catch (err) {
      console.error(err);
      setError('Failed to generate itinerary. The model may be unavailable or the request could not be processed. Please try again later.');
    } finally {
      setIsLoading(false);
    }
  }, []);

  return (
    <div className="min-h-screen flex flex-col font-sans text-slate-800 dark:text-slate-200">
      <Header />
      <main className="flex-grow container mx-auto px-4 py-8 md:py-12">
        <div className="max-w-4xl mx-auto">
          <section id="planner-form" className="mb-12">
            <PlannerForm onSubmit={handleGenerateItinerary} isLoading={isLoading} />
          </section>

          <section id="itinerary-display">
            {isLoading && <LoadingSpinner />}
            {error && <ErrorMessage message={error} />}
            {itinerary && <ItineraryDisplay itinerary={itinerary} />}
            {!isLoading && !error && !itinerary && <WelcomeMessage />}
          </section>
        </div>
      </main>
      <Footer />
    </div>
  );
};

export default App;
