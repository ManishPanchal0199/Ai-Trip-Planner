
import React from 'react';
import { ItineraryDay } from '../types';

interface ItineraryCardProps {
  dayPlan: ItineraryDay;
}

const ActivityIcon: React.FC<{className?: string}> = ({ className }) => (
    <svg xmlns="http://www.w3.org/2000/svg" fill="none" viewBox="0 0 24 24" strokeWidth={1.5} stroke="currentColor" className={className}>
        <path strokeLinecap="round" strokeLinejoin="round" d="M9 6.75V15m6-6v8.25m.5-10.5h-7a2.25 2.25 0 00-2.25 2.25v10.5a2.25 2.25 0 002.25 2.25h7.5a2.25 2.25 0 002.25-2.25v-10.5a2.25 2.25 0 00-2.25-2.25z" />
    </svg>
);

const FoodIcon: React.FC<{className?: string}> = ({ className }) => (
    <svg xmlns="http://www.w3.org/2000/svg" fill="none" viewBox="0 0 24 24" strokeWidth={1.5} stroke="currentColor" className={className}>
        <path strokeLinecap="round" strokeLinejoin="round" d="M21.75 8.25v12.75a1.5 1.5 0 01-1.5 1.5H3.75a1.5 1.5 0 01-1.5-1.5V8.25a1.5 1.5 0 011.5-1.5h16.5a1.5 1.5 0 011.5 1.5z" />
        <path strokeLinecap="round" strokeLinejoin="round" d="M21.75 8.25c0-3.314-2.686-6-6-6s-6 2.686-6 6" />
    </svg>
);


export const ItineraryCard: React.FC<ItineraryCardProps> = ({ dayPlan }) => {
  return (
    <div className="bg-white dark:bg-gray-800 rounded-xl shadow-lg overflow-hidden transition-all duration-300 hover:shadow-2xl hover:scale-[1.02]">
      <div className="p-6">
        <div className="flex items-center mb-4">
          <div className="bg-blue-100 dark:bg-blue-900/50 text-blue-600 dark:text-blue-300 rounded-full h-12 w-12 flex items-center justify-center font-bold text-xl mr-4">
            {dayPlan.day}
          </div>
          <div>
            <p className="text-sm font-semibold text-blue-500 uppercase tracking-wider">Day {dayPlan.day}</p>
            <h3 className="text-xl font-bold text-slate-900 dark:text-white">{dayPlan.title}</h3>
          </div>
        </div>
        
        <div className="grid grid-cols-1 md:grid-cols-2 gap-6">
            <div>
                <div className="flex items-center mb-3">
                    <ActivityIcon className="h-6 w-6 text-green-500 mr-2"/>
                    <h4 className="font-semibold text-lg text-slate-800 dark:text-slate-200">Activities</h4>
                </div>
                <ul className="space-y-2 pl-1">
                {dayPlan.activities.map((activity, index) => (
                    <li key={index} className="flex items-start">
                        <svg className="w-4 h-4 mr-2 mt-1 text-green-500 flex-shrink-0" fill="currentColor" viewBox="0 0 20 20">
                            <path fillRule="evenodd" d="M10 18a8 8 0 100-16 8 8 0 000 16zm3.707-9.293a1 1 0 00-1.414-1.414L9 10.586 7.707 9.293a1 1 0 00-1.414 1.414l2 2a1 1 0 001.414 0l4-4z" clipRule="evenodd" />
                        </svg>
                        <span className="text-slate-600 dark:text-slate-400">{activity}</span>
                    </li>
                ))}
                </ul>
            </div>
            
            <div>
                 <div className="flex items-center mb-3">
                    <FoodIcon className="h-6 w-6 text-orange-500 mr-2"/>
                    <h4 className="font-semibold text-lg text-slate-800 dark:text-slate-200">Food Suggestions</h4>
                </div>
                <ul className="space-y-2 pl-1">
                {dayPlan.food_suggestions.map((food, index) => (
                    <li key={index} className="flex items-start">
                        <svg className="w-4 h-4 mr-2 mt-1 text-orange-500 flex-shrink-0" fill="currentColor" viewBox="0 0 20 20">
                             <path d="M10 3.5a1.5 1.5 0 013 0V4a1 1 0 01-2 0V3.5zM10 8.5a1.5 1.5 0 013 0V9a1 1 0 01-2 0V8.5zM10 13.5a1.5 1.5 0 013 0V14a1 1 0 01-2 0v-.5z" />
                        </svg>
                       <span className="text-slate-600 dark:text-slate-400">{food}</span>
                    </li>
                ))}
                </ul>
            </div>
        </div>
      </div>
    </div>
  );
};
