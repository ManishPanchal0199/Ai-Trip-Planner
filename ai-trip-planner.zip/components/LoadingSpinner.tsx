
import React from 'react';

export const LoadingSpinner: React.FC = () => {
  return (
    <div className="text-center py-10">
        <div className="w-16 h-16 border-4 border-dashed rounded-full animate-spin-slow border-blue-500 mx-auto"></div>
        <h2 className="text-xl font-semibold mt-4 text-slate-700 dark:text-slate-300">Generating Your Adventure...</h2>
        <p className="text-slate-500 dark:text-slate-400 mt-2">Our AI is crafting the perfect plan. Please wait a moment.</p>
    </div>
  );
};
