
import React from 'react';
import { ItineraryDay } from '../types';
import { ItineraryCard } from './ItineraryCard';

interface ItineraryDisplayProps {
  itinerary: ItineraryDay[];
}

export const ItineraryDisplay: React.FC<ItineraryDisplayProps> = ({ itinerary }) => {
  return (
    <div className="space-y-8">
      {itinerary.map((dayPlan) => (
        <ItineraryCard key={dayPlan.day} dayPlan={dayPlan} />
      ))}
    </div>
  );
};
