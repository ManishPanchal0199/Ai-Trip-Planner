
import React from 'react';

const MapIcon: React.FC<{className?: string}> = ({ className }) => (
    <svg xmlns="http://www.w3.org/2000/svg" fill="none" viewBox="0 0 24 24" strokeWidth={1.5} stroke="currentColor" className={className}>
      <path strokeLinecap="round" strokeLinejoin="round" d="M15 10.5a3 3 0 11-6 0 3 3 0 016 0z" />
      <path strokeLinecap="round" strokeLinejoin="round" d="M19.5 10.5c0 7.142-7.5 11.25-7.5 11.25S4.5 17.642 4.5 10.5a7.5 7.5 0 1115 0z" />
    </svg>
);


export const WelcomeMessage: React.FC = () => {
  return (
    <div className="text-center bg-white dark:bg-gray-800 p-8 rounded-2xl shadow-md">
      <MapIcon className="w-16 h-16 mx-auto text-blue-500 animate-bounce-slow" />
      <h2 className="mt-4 text-2xl font-bold text-slate-900 dark:text-white">Your Next Adventure Awaits</h2>
      <p className="mt-2 text-slate-600 dark:text-slate-400">
        Fill out the form above to generate a personalized travel itinerary powered by AI.
      </p>
    </div>
  );
};
