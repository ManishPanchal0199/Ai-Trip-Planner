
import { GoogleGenAI, Type } from "@google/genai";
import { ItineraryDay } from '../types';

const API_KEY = process.env.API_KEY;

if (!API_KEY) {
  throw new Error("API_KEY environment variable not set");
}

const ai = new GoogleGenAI({ apiKey: API_KEY });

const itinerarySchema = {
  type: Type.ARRAY,
  items: {
    type: Type.OBJECT,
    properties: {
      day: {
        type: Type.INTEGER,
        description: 'The day number of the itinerary, starting from 1.'
      },
      title: {
        type: Type.STRING,
        description: 'A creative and descriptive title for the day\'s plan.'
      },
      activities: {
        type: Type.ARRAY,
        items: {
          type: Type.STRING,
        },
        description: 'A list of 3-5 activities planned for the day. Each activity should be a concise sentence.'
      },
      food_suggestions: {
        type: Type.ARRAY,
        items: {
          type: Type.STRING
        },
        description: 'A list of 2-3 food or restaurant suggestions for the day, relevant to the location and activities.'
      }
    },
    required: ['day', 'title', 'activities', 'food_suggestions'],
  }
};


export const generateItinerary = async (destination: string, duration: number): Promise<ItineraryDay[]> => {
  const prompt = `Create a detailed ${duration}-day travel itinerary for a trip to ${destination}. The plan should be engaging and practical for a tourist. For each day, provide a unique title, a list of activities, and some local food suggestions.`;

  try {
    const response = await ai.models.generateContent({
      model: "gemini-2.5-flash",
      contents: prompt,
      config: {
        responseMimeType: "application/json",
        responseSchema: itinerarySchema,
        temperature: 0.7,
        topP: 0.95,
      },
    });

    const jsonText = response.text.trim();
    const itinerary = JSON.parse(jsonText) as ItineraryDay[];
    
    // Simple validation
    if (!Array.isArray(itinerary) || itinerary.length === 0) {
      throw new Error("Invalid itinerary format received from API.");
    }

    return itinerary;

  } catch (error) {
    console.error("Error generating itinerary:", error);
    throw new Error("Could not generate itinerary from the AI model.");
  }
};
